const app=document.getElementById('app');
const soundBtn=document.getElementById('soundBtn');
let soundOn=true;
const state={name:'',group:'',level:'',score:0,correct:0,wrong:0,streak:0,hints:0,q:0,start:null,elapsed:0,material:0,answered:false};
const materials=[
 {icon:'💪',title:'Gaya Otot',text:'Gaya otot adalah gaya yang dihasilkan oleh kerja otot manusia atau hewan. Gaya ini dapat membuat benda bergerak, berhenti, berubah arah, atau berubah bentuk.',example:'Contoh: mendorong meja, mengangkat tas, menendang bola, dan menarik pintu.'},
 {icon:'🍎',title:'Gaya Gravitasi',text:'Gaya gravitasi adalah gaya tarik bumi yang membuat benda jatuh ke bawah dan membuat kita tetap berada di permukaan bumi.',example:'Contoh: buah jatuh dari pohon dan pensil yang terlepas dari tangan jatuh ke lantai.'},
 {icon:'🧲',title:'Gaya Magnet',text:'Gaya magnet adalah gaya tarik atau tolak yang ditimbulkan oleh magnet. Magnet dapat menarik benda tertentu, terutama benda yang mengandung besi.',example:'Contoh: magnet menarik klip kertas atau paku besi.'},
 {icon:'🛞',title:'Gaya Gesek',text:'Gaya gesek muncul ketika dua permukaan saling bersentuhan. Gaya ini dapat memperlambat atau menghentikan gerak benda.',example:'Contoh: rem sepeda menggunakan gaya gesek agar roda berhenti.'}
];
const questions=[
 {q:'Dina mendorong meja hingga meja bergeser. Gaya yang digunakan adalah …',a:['gaya otot','gaya gravitasi','gaya magnet','gaya gesek'],c:0},
 {q:'Buah yang terlepas dari pohon jatuh ke tanah karena adanya …',a:['gaya magnet','gaya gravitasi','gaya otot','gaya gesek'],c:1},
 {q:'Benda berikut yang paling mudah ditarik magnet adalah …',a:['penghapus karet','paku besi','pensil kayu','kertas'],c:1},
 {q:'Fungsi gaya gesek pada rem sepeda adalah …',a:['membuat sepeda terbang','menghentikan atau memperlambat roda','menarik sepeda ke atas','membuat roda menjadi magnet'],c:1},
 {q:'Saat menendang bola, gaya otot dapat menyebabkan bola …',a:['berubah menjadi magnet','bergerak','selalu jatuh lurus','menghilang'],c:1},
 {q:'Mengapa kita tidak melayang ketika berdiri di halaman sekolah?',a:['karena gaya magnet','karena gaya gravitasi bumi menarik kita','karena gaya gesek udara','karena gaya otot kaki'],c:1},
 {q:'Kegiatan yang menunjukkan gaya magnet adalah …',a:['menarik paku dengan magnet','mendorong kursi','menendang bola','menjatuhkan batu'],c:0},
 {q:'Sepatu olahraga memiliki sol yang bertekstur agar …',a:['mengurangi berat tubuh','menambah gaya gesek agar tidak mudah tergelincir','menjadi magnet','menarik benda ke atas'],c:1},
 {q:'Raka menarik gerobak dengan tangannya. Perubahan yang paling mungkin terjadi adalah …',a:['gerobak bergerak','gerobak menjadi magnet','gerobak berubah warna','gravitasi hilang'],c:0},
 {q:'Jika permukaan lantai sangat licin, gaya gesek antara sepatu dan lantai cenderung …',a:['lebih besar','lebih kecil','menjadi gaya magnet','tidak berkaitan dengan gerak'],c:1}
];
function footer(){document.getElementById('footer').style.display='block'}
function screen(html){app.innerHTML=html;window.scrollTo({top:0,behavior:'smooth'});footer()}
function home(){screen(`<section class="screen active home-menu"><div class="hero-copy"><div class="eyebrow">IPAS Kelas 4 — Gaya di Sekitar Kita</div><h1 class="title">🔎 DETEKTIF<span>GAYA</span></h1><div class="subtitle">Petualangan Mencari Rahasia Gaya</div><p class="tagline">“Ayo temukan rahasia gaya di sekitar kita!”</p><div class="main-menu"><button class="menu-card material-menu" onclick="materialMenu()"><span class="menu-icon">📚</span><span class="menu-title">MATERI</span><small>Pelajari Gaya Otot, Gravitasi, Magnet, dan Gesek + percobaan digital</small></button><button class="menu-card game-menu" onclick="howto()"><span class="menu-icon">🎮</span><span class="menu-title">MULAI GAME</span><small>Isi identitas, pilih tantangan, lalu pecahkan 10 misteri</small></button><button class="menu-card teacher-menu" onclick="teacher()"><span class="menu-icon">👩‍🏫</span><span class="menu-title">HALAMAN GURU</span><small>Lihat hasil nilai, skor, bintang, dan unduh rekap CSV</small></button></div></div><div class="hero-art"><img class="detective" src="https://gayadisekitarkita-ipas-kelas4-anf.netlify.app/img/detective-cut.png" alt="Dinda si detektif cilik"></div></section>`) }
function materialMenu(){screen(`<section class="panel screen active"><h1>📚 MATERI GAYA DI SEKITAR KITA</h1><p style="text-align:center;font-weight:800">Pilih materi yang ingin kamu pelajari. Setiap materi dilengkapi contoh kehidupan sehari-hari dan percobaan digital.</p><div class="material-menu-grid">${materials.map((m,i)=>`<button class="material-menu-card" onclick="openMaterial(${i})"><span>${m.icon}</span><b>${m.title}</b><small>Pelajari & coba simulasi</small></button>`).join('')}</div><div class="buttons" style="margin-top:24px"><button class="btn secondary" onclick="home()">🏠 Kembali ke Beranda</button><button class="btn primary" onclick="howto()">🎮 Mulai Game</button></div></section>`) }
function openMaterial(i){state.material=i;material('standalone')}
function howto(){screen(`<section class="panel screen active"><h1>📖 Cara Bermain</h1><div class="steps"><div class="step">✍️ Tulis nama, pilih kelompokmu, lalu pilih tingkat tantangan.</div><div class="step">📚 Baca Bekal Detektif Gaya dan coba semua percobaan digitalnya.</div><div class="step">🔎 Jawab 10 misteri. Setiap jawaban benar memberi +10 poin dan satu petunjuk.</div><div class="step">🔥 Jawab benar berturut-turut untuk mendapat bonus beruntun!</div><div class="step">🏆 Kumpulkan bintang dan bantu kelompokmu menjadi juara. Hasilmu tersimpan untuk dilihat guru.</div></div><div class="buttons" style="margin-top:24px"><button class="btn primary" onclick="identity()">SIAP, DETEKTIF! 👍</button></div></section>`)}
function identity(){screen(`<section class="panel screen active"><h1>🪪 IDENTITAS DETEKTIF</h1><p style="text-align:center;font-weight:800">Isi kartu detektifmu sebelum berangkat bertualang!</p><div class="identity"><div class="identity-art"><img src="https://gayadisekitarkita-ipas-kelas4-anf.netlify.app/img/detective-cut.png" alt="Dinda"><div class="speech">Halo! Aku Dinda, detektif cilik. Siapa namamu? 😊</div></div><div><div class="field"><label>1 Nama Pemain</label><input id="name" placeholder="Tulis namamu di sini..." value="${state.name}"></div><div class="field"><label>2 Pilih Kelompok</label><div class="choice-grid" id="groups">${[1,2,3,4,5,6].map(n=>`<button class="choice ${state.group==n?'selected':''}" onclick="pick('group',${n},this)">Kelompok ${n}</button>`).join('')}</div></div><div class="field"><label>3 Pilih Tingkat Tantangan</label><div class="choice-grid" id="levels"><button class="choice ${state.level==='Mudah'?'selected':''}" onclick="pick('level','Mudah',this)">🌱 Mudah</button><button class="choice ${state.level==='Sedang'?'selected':''}" onclick="pick('level','Sedang',this)">⭐ Sedang</button><button class="choice ${state.level==='Sulit'?'selected':''}" onclick="pick('level','Sulit',this)">🔥 Sulit</button></div></div><div id="identityNotice" class="notice">Lengkapi nama, kelompok, dan tingkat tantangan terlebih dahulu.</div><div class="buttons"><button class="btn secondary" onclick="howto()">⬅ Kembali</button><button class="btn primary" onclick="startGame()">🚀 MULAI GAME</button></div></div></div></section>`)}
function pick(key,val,el){state[key]=val;el.parentElement.querySelectorAll('.choice').forEach(x=>x.classList.remove('selected'));el.classList.add('selected')}
function startGame(){state.name=document.getElementById('name').value.trim();const n=document.getElementById('identityNotice');if(!state.name||!state.group||!state.level){n.classList.add('show');return}Object.assign(state,{score:0,correct:0,wrong:0,streak:0,hints:0,q:0,start:Date.now(),elapsed:0,material:0,answered:false});material()}
function material(mode){
 const m=materials[state.material];
 screen(`<section class="panel screen active">
   <h1>📚 BEKAL DETEKTIF GAYA</h1>
   <p style="text-align:center;font-weight:800">Pelajari bekal ini dulu, ya!</p>
   <div class="material-card">
     <div class="material-icon">${m.icon}</div><h2>${m.title}</h2>
     <p>${m.text}</p>
     <div class="example"><b>💡 Contoh sehari-hari:</b><br>${m.example}</div>
   </div>
   ${experimentHTML(state.material)}
   <div class="stats"><div class="stat">🔥 ${state.streak}</div><div class="stat">⭐ ${state.score}</div><div class="stat">🔎 ${state.hints}</div></div>
   <div class="buttons">${state.material>0?`<button class="btn secondary" onclick="${mode==='standalone'?'materialMenu()':'materialPrev()'}">⬅ Kembali</button>`:`<button class="btn secondary" onclick="${mode==='standalone'?'materialMenu()':'howto()'}">⬅ Kembali</button>`}<button class="btn primary" onclick="${mode==='standalone'?(state.material<materials.length-1?`openMaterial(${state.material+1})`:'identity()'):'nextMaterial()'}">${mode==='standalone'?(state.material<materials.length-1?'MATERI BERIKUTNYA ➜':'🎮 MULAI GAME ➜'):(state.material<materials.length-1?'LANJUT ➜':'🔎 MULAI MISI ➜')}</button></div>
 </section>`);
}
function materialPrev(){if(state.material>0){state.material--;material()}else{howto()}}
function experimentHTML(i){
 if(i===0) return `<div class="experiment-card muscle-exp">
   <div class="experiment-title">🧪 Percobaan Digital: Dorong Kotak</div>
   <p>Atur kekuatan otot, lalu tekan <b>DORONG!</b> Amati perubahan gerak kotak.</p>
   <div class="sim-stage"><div class="force-meter"><span id="muscleMeter">50%</span></div><div id="muscleBox" class="sim-box">📦</div><div class="ground"></div></div>
   <label class="range-label">💪 Kekuatan otot: <b id="muscleValue">50</b></label>
   <input class="range" id="muscleRange" type="range" min="10" max="100" value="50" oninput="updateMuscle(this.value)">
   <div class="experiment-result" id="muscleResult">Semakin besar gaya, semakin besar perubahan geraknya.</div>
   <div class="buttons"><button class="btn primary small" onclick="runMuscle()">💪 DORONG!</button><button class="btn secondary small" onclick="resetExperiment(0)">↺ Reset</button></div>
 </div>`;
 if(i===1) return `<div class="experiment-card gravity-exp">
   <div class="experiment-title">🧪 Percobaan Digital: Jatuhkan Bola</div>
   <p>Pilih ketinggian, lalu lepaskan bola. Perhatikan bahwa gravitasi menarik benda ke bawah.</p>
   <div class="drop-stage"><div id="gravityBall" class="gravity-ball">🍎</div><div class="drop-ground"></div><div class="height-line"></div></div>
   <label class="range-label">📏 Ketinggian: <b id="gravityValue">60</b> m</label>
   <input class="range" id="gravityRange" type="range" min="20" max="100" value="60" oninput="updateGravity(this.value)">
   <div class="experiment-result" id="gravityResult">Tekan JATUHKAN untuk melihat gerak jatuh.</div>
   <div class="buttons"><button class="btn primary small" onclick="runGravity()">🍎 JATUHKAN!</button><button class="btn secondary small" onclick="resetExperiment(1)">↺ Reset</button></div>
 </div>`;
 if(i===2) return `<div class="experiment-card magnet-exp">
   <div class="experiment-title">🧪 Percobaan Digital: Magnet dan Benda</div>
   <p>Geser magnet mendekati benda. Tidak semua benda tertarik magnet.</p>
   <div class="magnet-stage"><div class="magnet-object">🧲</div><div id="magnetPaper" class="magnet-target">📎</div><div id="magnetWood" class="magnet-target wood">✏️</div></div>
   <label class="range-label">🧲 Jarak magnet: <b id="magnetValue">70</b>%</label>
   <input class="range" id="magnetRange" type="range" min="0" max="100" value="70" oninput="updateMagnet(this.value)">
   <div class="experiment-result" id="magnetResult">Dekatkan magnet untuk menguji benda.</div>
   <div class="buttons"><button class="btn primary small" onclick="runMagnet()">🧲 UJI MAGNET!</button><button class="btn secondary small" onclick="resetExperiment(2)">↺ Reset</button></div>
 </div>`;
 return `<div class="experiment-card friction-exp">
   <div class="experiment-title">🧪 Percobaan Digital: Gaya Gesek</div>
   <p>Pilih permukaan dan atur gaya dorong. Bandingkan seberapa jauh benda bergerak.</p>
   <div class="friction-stage"><div id="frictionBox" class="friction-box">🛹</div><div class="friction-track" id="frictionTrack"></div></div>
   <div class="friction-controls"><div><label class="range-label">🖐️ Gaya dorong: <b id="pushValue">60</b></label><input class="range" id="pushRange" type="range" min="10" max="100" value="60" oninput="updatePush(this.value)"></div><div><label class="range-label">🧱 Permukaan</label><select id="surfaceSelect" class="surface-select" onchange="updateSurface(this.value)"><option value="licin">Lantai licin</option><option value="kayu">Kayu</option><option value="karpet">Karpet kasar</option></select></div></div>
   <div class="experiment-result" id="frictionResult">Pilih permukaan, lalu tekan DORONG!</div>
   <div class="buttons"><button class="btn primary small" onclick="runFriction()">🛹 DORONG!</button><button class="btn secondary small" onclick="resetExperiment(3)">↺ Reset</button></div>
 </div>`;
}
function updateMuscle(v){const el=document.getElementById('muscleValue'),m=document.getElementById('muscleMeter');if(el)el.textContent=v;if(m)m.textContent=v+'%'}
function runMuscle(){const v=+document.getElementById('muscleRange').value,b=document.getElementById('muscleBox'),r=document.getElementById('muscleResult');b.classList.remove('push-animation');void b.offsetWidth;b.style.setProperty('--push',Math.max(25,v*2.8)+'px');b.classList.add('push-animation');r.innerHTML=v>=70?'💪 Gaya otot besar membuat kotak bergerak lebih jauh!':'💪 Kotak bergerak karena mendapat gaya dorong dari otot.';beep(520)}
function updateGravity(v){const el=document.getElementById('gravityValue');if(el)el.textContent=v}
function runGravity(){const v=+document.getElementById('gravityRange').value,b=document.getElementById('gravityBall'),r=document.getElementById('gravityResult');b.classList.remove('drop-animation');void b.offsetWidth;b.style.setProperty('--fall',Math.min(190,70+v*.85)+'px');b.classList.add('drop-animation');r.textContent='⬇️ Gravitasi menarik apel ke bawah menuju permukaan bumi.';beep(330)}
function updateMagnet(v){const el=document.getElementById('magnetValue');if(el)el.textContent=v}
function runMagnet(){const v=+document.getElementById('magnetRange').value,p=document.getElementById('magnetPaper'),w=document.getElementById('magnetWood'),r=document.getElementById('magnetResult');p.classList.remove('magnet-pull');w.classList.remove('magnet-shake');void p.offsetWidth;if(v<=45){p.classList.add('magnet-pull');r.innerHTML='🧲📎 Tertarik! Klip kertas bergerak mendekati magnet.';beep(720)}else{p.classList.add('magnet-shake');r.innerHTML='🔎 Magnet masih terlalu jauh. Dekatkan magnet lagi.';beep(250)}if(v<=30){w.classList.add('magnet-shake');r.innerHTML+=' ✏️ Pensil kayu tidak tertarik magnet.'}}
function updatePush(v){const el=document.getElementById('pushValue');if(el)el.textContent=v}
function updateSurface(v){const t=document.getElementById('frictionTrack');if(t)t.dataset.surface=v}
function runFriction(){const force=+document.getElementById('pushRange').value,s=document.getElementById('surfaceSelect').value,b=document.getElementById('frictionBox'),r=document.getElementById('frictionResult'),coef={licin:1,kayu:.68,karpet:.38}[s];b.classList.remove('friction-move');void b.offsetWidth;b.style.setProperty('--slide',Math.max(30,force*coef*2.4)+'px');b.classList.add('friction-move');const names={licin:'lantai licin',kayu:'kayu',karpet:'karpet kasar'};r.innerHTML=`🛞 Pada <b>${names[s]}</b>, gaya gesek ${s==='licin'?'lebih kecil':'lebih besar'} sehingga benda bergerak ${s==='licin'?'lebih jauh':'lebih pendek'}.`;beep(450)}
function resetExperiment(i){material();}
function nextMaterial(){if(state.material<materials.length-1){state.material++;material()}else{question()}}
function question(){const x=questions[state.q];const pct=(state.q/questions.length)*100;screen(`<section class="panel screen active"><div class="mission-head"><h1 style="margin:0">🔎 MISTERI ${state.q+1}/10</h1><div class="stats"><div class="stat">⭐ ${state.score}</div><div class="stat">🔥 ${state.streak}</div><div class="stat">🔎 ${state.hints}</div></div></div><div class="progress"><i style="width:${pct}%"></i></div><div class="question">${x.q}</div><div class="answers">${x.a.map((a,i)=>`<button class="answer" id="ans${i}" onclick="answer(${i})">${String.fromCharCode(65+i)}. ${a}</button>`).join('')}</div><div id="feedback" class="feedback"></div></section>`)}
function answer(i){if(state.answered)return;state.answered=true;const x=questions[state.q];document.querySelectorAll('.answer').forEach(b=>b.disabled=true);if(i===x.c){state.correct++;state.streak++;state.hints++;state.score+=10+(state.streak>=3?5:0);document.getElementById('ans'+i).classList.add('correct');document.getElementById('feedback').textContent=state.streak>=3?'🔥 Benar! Bonus beruntun +5 poin!':'🎉 Benar! +10 poin dan +1 petunjuk.';beep(660)}else{state.wrong++;state.streak=0;document.getElementById('ans'+i).classList.add('wrong');document.getElementById('ans'+x.c).classList.add('correct');document.getElementById('feedback').textContent='💡 Belum tepat. Jawaban yang benar sudah ditandai.';beep(180)}setTimeout(()=>{state.q++;state.answered=false;if(state.q<questions.length)question();else finish()},1100)}
function finish(){state.elapsed=Math.round((Date.now()-state.start)/1000);saveResult();const stars=state.correct>=8?3:state.correct>=4?2:1;confetti();screen(`<section class="panel screen active result"><div style="font-size:72px">🏆</div><h1>MISI SELESAI!</h1><div class="big-star">${'⭐'.repeat(stars)}</div><div class="score">${state.score} Total Poin</div><div class="result-grid"><div class="result-box"><b>${state.correct}/10</b>Jawaban Benar</div><div class="result-box"><b>${formatTime(state.elapsed)}</b>Waktu</div><div class="result-box"><b>${state.hints}</b>Petunjuk</div></div><p><b>${state.name}</b> • Kelompok ${state.group} • ${state.level}</p><div class="buttons"><button class="btn primary" onclick="identity()">🔁 MAIN LAGI</button><button class="btn secondary" onclick="identity()">⏫ LEVEL BERIKUTNYA</button><button class="btn green" onclick="home()">🏠 BERANDA</button></div></section>`)}
function formatTime(s){return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
function saveResult(){const rows=JSON.parse(localStorage.getItem('detektifGayaResults')||'[]');rows.push({time:new Date().toLocaleString('id-ID'),name:state.name,group:'Kelompok '+state.group,level:state.level,correct:state.correct,score:state.score,stars:state.correct>=8?3:state.correct>=4?2:1,duration:formatTime(state.elapsed)});localStorage.setItem('detektifGayaResults',JSON.stringify(rows))}
function teacher(){const rows=JSON.parse(localStorage.getItem('detektifGayaResults')||'[]');screen(`<section class="panel screen active"><h1>👩‍🏫 HALAMAN GURU</h1><p style="text-align:center;font-weight:800">Rekap hasil permainan Detektif Gaya untuk 6 kelompok.</p><div class="buttons" style="margin-bottom:18px"><button class="btn secondary" onclick="home()">🎮 Kembali ke Game</button><button class="btn green" onclick="downloadCSV()">⬇️ Unduh CSV</button><button class="btn primary" onclick="teacher()">🔄 Muat Ulang</button></div><div class="teacher-table-wrap"><table class="teacher-table"><thead><tr><th>Waktu</th><th>Nama Pemain</th><th>Kelompok</th><th>Level</th><th>Benar</th><th>Poin</th><th>Bintang</th><th>Durasi</th></tr></thead><tbody>${rows.length?rows.slice().reverse().map(r=>`<tr><td>${r.time}</td><td>${esc(r.name)}</td><td>${r.group}</td><td>${r.level}</td><td>${r.correct}/10</td><td>${r.score}</td><td>${'⭐'.repeat(r.stars)}</td><td>${r.duration}</td></tr>`).join(''):`<tr><td colspan="8" class="empty">Memuat data... Belum ada hasil permainan.</td></tr>`}</tbody></table></div></section>`)}
function esc(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function downloadCSV(){const rows=JSON.parse(localStorage.getItem('detektifGayaResults')||'[]');if(!rows.length){alert('Belum ada data hasil.');return}const head=['Waktu','Nama Pemain','Kelompok','Level','Benar','Poin','Bintang','Durasi'];const lines=[head,...rows.map(r=>[r.time,r.name,r.group,r.level,r.correct+'/10',r.score,r.stars,r.duration])].map(a=>a.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(','));const blob=new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='hasil-detektif-gaya.csv';a.click();URL.revokeObjectURL(a.href)}
function beep(freq){if(!soundOn)return;try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.frequency.value=freq;o.type='sine';g.gain.value=.04;o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.12)}catch(e){}}
function confetti(){const wrap=document.createElement('div');wrap.className='confetti';for(let i=0;i<42;i++){const s=document.createElement('i');s.textContent=['⭐','✨','🎉','💫'][i%4];s.style.left=(Math.random()*100)+'%';s.style.animationDelay=(Math.random()*.5)+'s';s.style.setProperty('--drift',(Math.random()*160-80)+'px');wrap.appendChild(s)}document.body.appendChild(wrap);setTimeout(()=>wrap.remove(),2600)}
soundBtn.onclick=()=>{soundOn=!soundOn;soundBtn.textContent=soundOn?'🔊':'🔇'};
home();
